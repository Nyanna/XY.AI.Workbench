package xyx.ai.proxy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProxyApplication {
	private static Logger LOG = LoggerFactory.getLogger(ProxyApplication.class); 

	public static void main(String[] args) {
		SpringApplication.run(ProxyApplication.class, args);
		LOG.info("Applocation started");
	}

}
