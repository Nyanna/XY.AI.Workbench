package xyx.ai.proxy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;

@RestController
public class BatchProxyController {
	private static Logger LOG = LoggerFactory.getLogger(BatchProxyController.class); 

	@GetMapping("/**")
	public Object handleGet() {
        LOG.info("Get Request");
		return "Get";
	}
	
	@PostMapping("/**")
	public Object handlePost(@RequestBody String requestBody, HttpServletRequest request) {
        LOG.info("Url: {}", request.getRequestURL().toString());
        LOG.info("Query: {}", request.getQueryString());
        LOG.info("Body: {}", requestBody);
		return "Post";
	}
	
	@PutMapping("/**")
	public Object handlePut(@RequestBody String requestBody) {
        LOG.info("Whole Request: {}", requestBody);
		return "Put";
	}
}
